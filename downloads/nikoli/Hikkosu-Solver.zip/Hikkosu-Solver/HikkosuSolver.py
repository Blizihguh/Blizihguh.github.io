"""
Hikkosu Generator/Solver
John Licitra 2020
"""
import sys
import copy
import time
import cProfile
from random import randint, sample

# Enables extra prints
global CONDITIONS, PROP
CONDITIONS = {"Bad_Arrow": 0, "No_Line": 0, "OOB_Line": 0, "Connected_Circles": 0, "Invalid_L": 0, "Invalid_Walu": 0, "Invalid_Back_L": 0, "Invalid_Back_Walu": 0, "Invalid_Horiz": 0, "Invalid_Vert": 0, "2_Circle": 0}
PROP = {"num": 0, "denom": 0}
DEBUG = False
# Solution to puzzle will be stored here
global MULTIPLE_SOLUTIONS, SOLUTION # I have no idea why this has to be declared global when it's at the top of the file, but it didn't work until I did
MULTIPLE_SOLUTIONS = False
SOLUTION = None
# Used to remove a long if/elif chain in the while loop in is_solved and check_valid
# This is ugly as sin, but defining a dict of six lambdas 1,500,000 times instead of once is bad
SWITCHER = {
	"│": lambda curX,curY,prvX,prvY : (curX, curY-1) if curY < prvY else (curX, curY+1), 
	"─": lambda curX,curY,prvX,prvY : (curX-1, curY) if curX < prvX else (curX+1, curY),
	"┌": lambda curX,curY,prvX,prvY : (curX+1, curY) if curY < prvY else (curX, curY+1),
	"└": lambda curX,curY,prvX,prvY : (curX, curY-1) if curX < prvX else (curX+1, curY),
	"┐": lambda curX,curY,prvX,prvY : (curX, curY+1) if curX > prvX else (curX-1, curY),
	"┘": lambda curX,curY,prvX,prvY : (curX, curY-1) if curX > prvX else (curX-1, curY)
}

def debug_print(out):
	"""Print something iff DEBUG == True"""
	if DEBUG:
		print("##### DEBUG: ", end="")
		print(out)

class Hikkosu:
	"""Represents a Hikkosu board state"""
	def __init__(self, cG, rG, cC, eds, h, w, space, maxLen):
		self.cGrid = cG
		self.rGrid = rG
		self.cCoords = cC
		self.ends = eds # Number of additional arrows needed to satisfy the circles for the corresponding region
		# self.free = fr # Number of spaces left in the corresponding region
		self.height = h
		self.width = w
		self.space = space
		self.maxLen = maxLen
		
		if self.space == None:
			self.space = 0
			for row in self.cGrid:
				for c in row:
					if c == ".":
						self.space += 1

		self.maxLen = maxLen if maxLen != None else self.space

	def clone(self):
		# Python list comprehensions are amazing -- this is 4% of the speed of a double for loop, which itself is 1/8 the speed of deepcopy
		cg = [row[:] for row in self.cGrid]
		# f = {key:self.free[key] for key in self.free}
		return Hikkosu(cg, self.rGrid, self.cCoords, self.ends, self.height, self.width, self.space, self.maxLen)

	def disp(self):
		"""Print a Hikkosu to console"""
		try:
			for row in self.cGrid:
				for c in row:
					# PyPy has compatibility issues with the arrows >:
					if c == "↑":
						print("^", end="")
					elif c == "↓":
						print("v", end="")
					elif c == "←":
						print("<", end="")
					elif c == "→":
						print(">", end="")
					else:
						print(c, end="")
				print("")
			print("")
			for row in self.rGrid:
				for c in row:
					print(c, end="")
				print("")
		except:
			print("Print failed.")

	def set_tile(self, x, y, tile):
		self.cGrid[y][x] = tile
		self.space = self.space - 1 # It is assumed that the tile was not full already. This is dangerous, but speed is more important here
		# if self.rGrid[y][x] in self.ends:
		# 	self.free[self.rGrid[y][x]] -= 1
		# 	if tile in {"↑", "↓", "→", "←"}:
		# 		self.ends[self.rGrid[y][x]] -= 1

	def check_arrow_space(self):
		ends = {e: self.ends[e] for e in self.ends}
		for x in range(self.width):
			for y in range(self.height):
				if self.cGrid[y][x] in {".", "↑", "↓", "→", "←"} and self.rGrid[y][x] in ends:
					ends[self.rGrid[y][x]] -= 1
		for end in ends:
			if ends[end] > 0:
				return False
		return True

	def check_arrow_space_fast(self):
		for region in self.ends:
			if self.free[region] < self.ends[region]:
				return False
		return True

	def is_solved(self):
		# Grid must be full to be solved
		if not self.space == 0:
			return False
		visited = [[self.cGrid[j][i] for i in range(self.width)] for j in range(self.height)]
		for coords in self.cCoords:
			# First, get the line position
			nxt = False
			(x,y) = coords[1], coords[0]
			# Ensure that each circle only has one line coming off of it
			if x-1 >= 0 and (self.cGrid[y][x-1] == "─" or self.cGrid[y][x-1] == "┌" or self.cGrid[y][x-1] == "└" or self.cGrid[y][x-1] == "←"):
				nxt = (x-1,y)
			if y-1 >= 0 and (self.cGrid[y-1][x] == "│" or self.cGrid[y-1][x] == "┐" or self.cGrid[y-1][x] == "┌" or self.cGrid[y-1][x] == "↑"):
				if nxt:
					return False
				nxt = (x,y-1)
			if x+1 < self.width-1 and (self.cGrid[y][x+1] == "─" or self.cGrid[y][x+1] == "┘" or self.cGrid[y][x+1] == "┐" or self.cGrid[y][x+1] == "→"):
				if nxt:
					return False
				nxt = (x+1,y)
			if y+1 < self.height-1 and (self.cGrid[y+1][x] == "│" or self.cGrid[y+1][x] == "┘" or self.cGrid[y+1][x] == "└" or self.cGrid[y+1][x] == "↓"):
				if nxt:
					return False
				nxt = (x,y+1)
			# If there's no line, solution is invalid unless circle is already in its home region
			if not nxt and self.cGrid[y][x] != self.rGrid[y][x]:
				return False
			elif not nxt:
				# If there's no line, we can skip trying to follow it!
				continue
			# If there is a line, we must follow it to see where it leads
			(prvX, prvY) = x,y
			(curX, curY) = nxt[0], nxt[1]
			(nxtX, nxtY) = 0,0
			# If the line leads out of bounds, it's invalid
			if curX < 0 or curX >= self.width or curY < 0 or curY >= self.height:
				return False
			visited[curY][curX] = "#"
			rem = self.maxLen+1 # Infinite loop prevention
			while rem > 0 and self.cGrid[curY][curX] not in (".", "↑", "↓", "→", "←"):
				# Next, figure out which direction we're moving
				# If we're not moving in either direction, the line lead into a line without terminating in an arrow, which is invalid
				# This is some of the most disgusting logic I've ever written
				# Python can emulate switch statements with dictionaries, but if I wanted to do that kind of thing, I'd be writing this in Lua
				if self.cGrid[curY][curX] not in {"│", "─", "┌", "└", "┐", "┘"}:
					return False # Connected two circles
				(nxtX, nxtY) = SWITCHER[self.cGrid[curY][curX]](curX,curY,prvX,prvY)
				# nxt -> nxtPos; prevPos -> nxt
				(prvX, prvY) = curX, curY
				(curX, curY) = nxtX, nxtY
				rem = rem - 1
				# Validate new position before continuing
				if curX < 0 or curX >= self.width or curY < 0 or curY >= self.height:
					return False
				visited[curY][curX] = "#"
			if rem <= 0: # If we looped, it's invalid
				return False
			# We must have ended in an arrow, so ensure that the arrow is in the right region
			if self.cGrid[y][x] != self.rGrid[curY][curX]:
				return False
			# Also make sure the arrow is in the right direction
			if self.cGrid[curY][curX] == "↑" and curY >= prvY:
				return False
			elif self.cGrid[curY][curX] == "↓" and curY <= prvY:
				return False
			elif self.cGrid[curY][curX] == "→" and curX <= prvX:
				return False
			elif self.cGrid[curY][curX] == "←" and curX >= prvX:
				return False
		# If the grid is full but we haven't visited every tile, the solution doesn't work
		for row in visited:
			for c in row:
				if c in ("┘", "┐", "┌", "└", "─", "│", "↑", "↓", "→", "←"):
					return False
		# If none of the coords have returned False yet, our solution works!
		return True

	def check_valid(self):
		"""
		Returns False for certain things that might make a partial solution invalid!
		Specifically, checks the following things:
		- Every circle has exactly 1 line, or 0 lines and is in its region
		- Every arrow ends up in the region it's supposed to be in
		- No lines connect two circles to each other
		And does NOT check the following things:
		- Every tile being visited (if a grid is filled, is_solved will be called before this anyway)
		- Lines moving out of bounds (get_tiles handles this)
		- Lines connected in an invalid way (eg a horizontal bar moving into a vertical bar; get_tiles handles this)
		Note that this means we do a lot of "risky" indexing (ie, cGrid[y][x] where we haven't checked if y and x are in bounds).
		It isn't actually risky, because get_tiles will never create a situation in which a line moves out of bounds, and we're
		following the lines as we move our position around the grid.
		"""

		for coords in self.cCoords:
			# First, get the line position
			nxt = False
			(x,y) = coords[1], coords[0]
			if x-1 >= 0 and (self.cGrid[y][x-1] == "─" or self.cGrid[y][x-1] == "┌" or self.cGrid[y][x-1] == "└" or self.cGrid[y][x-1] == "←"):
				nxt = (x-1,y)
			if y-1 >= 0 and (self.cGrid[y-1][x] == "│" or self.cGrid[y-1][x] == "┐" or self.cGrid[y-1][x] == "┌" or self.cGrid[y-1][x] == "↑"):
				if nxt:
					return False
				nxt = (x,y-1)
			if x+1 < self.width-1 and (self.cGrid[y][x+1] == "─" or self.cGrid[y][x+1] == "┘" or self.cGrid[y][x+1] == "┐" or self.cGrid[y][x+1] == "→"):
				if nxt:
					return False
				nxt = (x+1,y)
			if y+1 < self.height-1 and (self.cGrid[y+1][x] == "│" or self.cGrid[y+1][x] == "┘" or self.cGrid[y+1][x] == "└" or self.cGrid[y+1][x] == "↓"):
				if nxt:
					return False
				nxt = (x,y+1)
			# If there's no line and the board is full, solution is invalid unless circle is already in its home region
			if not nxt and self.space == 0 and self.cGrid[y][x] != self.rGrid[y][x]:
				return False
			elif not nxt:
				# If there's no line, we can skip trying to follow it!
				continue
			# If there is a line, we must follow it to see where it leads
			(prvX, prvY) = x,y
			(curX, curY) = nxt[0], nxt[1]
			(nxtX, nxtY) = 0,0
			rem = self.maxLen+1 # Infinite loop prevention
			while rem > 0 and self.cGrid[curY][curX] not in (".", "↑", "↓", "→", "←"):
				# Next, figure out which direction we're moving
				# If we're not moving in either direction, the line lead into a line without terminating in an arrow, which is invalid
				# This is some of the most disgusting logic I've ever written
				# Python can emulate switch statements with dictionaries, but if I wanted to do that kind of thing, I'd be writing this in Lua
				if self.cGrid[curY][curX] not in {"│", "─", "┌", "└", "┐", "┘"}:
					return False # Connected two circles
				(nxtX, nxtY) = SWITCHER[self.cGrid[curY][curX]](curX,curY,prvX,prvY)
				# nxt -> nxtPos; prevPos -> nxt
				(prvX, prvY) = curX, curY
				(curX, curY) = nxtX, nxtY
				rem = rem - 1
			if rem <= 0: # If we looped, it's invalid
				return False
			# If we ended in an empty spot, this line is unfinished
			if self.cGrid[curY][curX] == ".":
				continue
			elif self.cGrid[y][x] != self.rGrid[curY][curX]: # Otherwise, make sure the arrow is in the right region
				return False
		return True

def get_tiles_fast(hik, x, y):
	cGrid = hik.cGrid
	isEnd         = hik.rGrid[y][x] in hik.ends
	canGoUp       = not y == 0 and cGrid[y-1][x] not in {"┘", "└", "─", "↓", "→", "←"}
	canGoDown     = not y == hik.height-1 and cGrid[y+1][x] not in {"┌", "┐", "─", "↑", "→", "←"}
	canGoLeft     = not x == 0 and cGrid[y][x-1] not in {"┘", "┐", "│", "↑", "↓", "→"}
	canGoRight    = not x == hik.width-1 and cGrid[y][x+1] not in {"┌", "└", "│", "↑", "↓", "←"}
	# Prune situations where we can't go anywhere
	if not (canGoUp or canGoDown or canGoLeft or canGoRight):
		return set() # We can't go anywhere u_u
	mustGoUp      = canGoUp and cGrid[y-1][x] in {"┐", "┌", "│", "↑"}
	mustGoDown    = canGoDown and cGrid[y+1][x] in {"┘", "└", "│", "↓"}
	mustGoLeft    = canGoLeft and cGrid[y][x-1] in {"┌", "└", "─", "←"}
	mustGoRight   = canGoRight and cGrid[y][x+1] in {"┘", "┐", "─", "→"}
	mustSum = mustGoUp + mustGoDown + mustGoLeft + mustGoRight
	# Optimize situations where we have to go in >1 direction
	# if mustSum > 2:
	# 	return set() # We have to go everywhere!!!
	if mustSum == 2:
		# We can save checks by just returning the right tile directly
		if mustGoUp:
			if mustGoDown:
				return {"│"}
			else:
				if mustGoLeft:
					return {"┘"}
				else:
					return {"└"}
		else:
			if mustGoDown:
				if mustGoLeft:
					return {"┐"}
				else:
					return {"┌"}
			else:
				return {"─"}

	tiles = set()
	if canGoUp and canGoDown and not mustGoLeft and not mustGoRight:
		tiles.add("│")
	if canGoLeft and canGoRight and not mustGoUp and not mustGoDown:
		tiles.add("─")
	if canGoUp and canGoLeft and not mustGoDown and not mustGoRight and cGrid[y-1][x-1] != "┌":
		tiles.add("┘")
	if canGoUp and canGoRight and not mustGoDown and not mustGoLeft and cGrid[y-1][x+1] != "┐":
		tiles.add("└")
	if canGoDown and canGoLeft and not mustGoUp and not mustGoRight and cGrid[y+1][x-1] != "└":
		tiles.add("┐")
	if canGoDown and canGoRight and not mustGoUp and not mustGoLeft and cGrid[y+1][x+1] != "┘":
		tiles.add("┌")
	if isEnd and canGoLeft and not mustGoUp and not mustGoDown and not mustGoRight:
		tiles.add("→")
	if isEnd and canGoUp and not mustGoLeft and not mustGoDown and not mustGoRight:
		tiles.add("↓")
	if isEnd and canGoRight and not mustGoLeft and not mustGoUp and not mustGoDown:
		tiles.add("←")
	if isEnd and canGoDown and not mustGoLeft and not mustGoRight and not mustGoUp:
		tiles.add("↑")

	return tiles

def handle_solve(hik):
	global SOLUTION, MULTIPLE_SOLUTIONS
	if SOLUTION:
		# Multiple solutions exist
		MULTIPLE_SOLUTIONS = True
		#hik.disp()
	else:
		SOLUTION = hik
		#print("Solution found!")
		#hik.disp()

def solve_hikkosu(hik):
	global MULTIPLE_SOLUTIONS, SOLUTION
	if MULTIPLE_SOLUTIONS:
		return # We've already found multiple solutions, so just clean up

	# Check if the puzzle is completely filled, and if so, if it's solved
	if hik.space == 0:
		if hik.is_solved():
			handle_solve(hik)
		return

	# Iterate over every empty tile on the board. If the tile has 0 possible lines,
	# the solution is invalid. If the tile has 1 possible line, fill it immediately and continue.
	# If all tiles have 2 or more possible lines, pick the one with the lowest and branch.
	# Additionally, if any forced move is made, loop again after making all possible forced moves,
	# as we may have forced additional moves.
	forcedMove = True
	minMoves = 11
	minInfo = (0, 0, None) # x, y, tiles
	while forcedMove:
		forcedMove = False
		minMoves = 11
		minInfo = (0, 0, None) # x, y, tiles
		for y in range(hik.height):
			for x in range(hik.width):
				# Skip non-empty tiles
				if hik.cGrid[y][x] != ".":
					continue
				# Check number of valid solutions
				tiles = get_tiles_fast(hik, x, y)
				numTiles = len(tiles)
				if numTiles == 0:
					return # Solution is invalid
				elif numTiles == 1:
					# Immediately make move, and ensure we loop again
					(foo,) = tiles # Janky hack, mate -- tuple unpacking lets us get the only element from a one-member set
					hik.set_tile(x,y,foo)
					if foo not in {"↑", "↓", "→", "←"}:
						if not hik.check_arrow_space():
							return False # A region does not have enough room to hold all the arrows it needs
					forcedMove = True
				elif numTiles < minMoves:
					# Tile is new minimum
					minMoves = numTiles
					minInfo = (x, y, tiles)

	# Check if the puzzle is completely filled, and if so, if it's solved
	if hik.space == 0:
		if hik.is_solved():
			handle_solve(hik)
		return

	# At this point, all forced moves have been made, and all tiles are verified to have at least two solutions
	try:
		for tile in minInfo[2]:
			h = hik.clone()
			h.set_tile(minInfo[0], minInfo[1], tile)
			if tile not in {"↑", "↓", "→", "←"}:
				if not h.check_arrow_space():
					continue # A region does not have enough room to hold all the arrows it needs
			if h.check_valid():
				solve_hikkosu(h)
	except TypeError as e: # This should only trigger if minInfo remains (0, 0, None), but this should only happen if hik.space == 0, which we catch already
		print(e)
		hik.disp()
		print(minInfo)
		print(hik.ends)
		print(hik.space)

def rgrid_from_text():
	with open(sys.argv[1], encoding="utf8") as f:
		info = f.readline().strip().split()
		height,width = int(info[0]), int(info[1])
		rGrid = [["#" for i in range(width)] for j in range(height)]
		regionSet = set()
		# Next n lines are region grid
		for i in range(height):
			row = f.readline().strip()
			for j in range(len(row)):
				rGrid[i][j] = row[j]
				if row[j] not in regionSet:
					regionSet.add(row[j])
	return (rGrid, regionSet, height, width)

def cgrid_bogo(rGrid, regionSet, numCircles):
	height = len(rGrid)
	width = len(rGrid[0])
	cGrid = [["." for i in range(width)] for j in range(height)]
	circles = []
	# Put circles into cGrid
	y,x = 0,0
	for circleIdx in range(numCircles):
		cGrid[y][x] = sample(regionSet, 1)[0]
		x = x + 1
		if x >= width:
			x = 0
			y = y + 1
	# Shuffle cGrid
	for i in range(width):
		for j in range(height):
			k = randint(0,width-1)
			l = randint(0,height-1)
			(cGrid[j][i], cGrid[l][k]) = (cGrid[l][k], cGrid[j][i])
	# Get circle coords
	cCoords = set()
	ends = {}
	# For every cell in the grid
	for i in range(height):
		for j in range(width):
			# If the cell isn't empty (ie, is a circle)
			if cGrid[i][j] != ".":
				cCoords.add((i,j)) # Add it to the list of circle coords
				if cGrid[i][j] in ends: # Update the ends count
					ends[cGrid[i][j]] += 1
				else:
					ends[cGrid[i][j]] = 1
	# Remove extraneous ends
	# Trying to combine this with the above loop produced bad results, because ends needs to have ALL end coords, even ones that start at 0
	for i in range(height):
		for j in range(width):
			if cGrid[i][j] == rGrid[i][j]:
				ends[cGrid[i][j]] = ends[cGrid[i][j]] - 1
	return (cGrid, cCoords, ends)

def init_from_text():
	# Arrow characters are UTF8, so if the puzzle we're loading is already solved, we need to open as UTF8
	with open(sys.argv[1], encoding="utf8") as f:
		# First line is height, width
		info = f.readline().strip().split()
		height,width = int(info[0]), int(info[1])
		cGrid = [["." for i in range(width)] for j in range(height)]
		rGrid = [["#" for i in range(width)] for j in range(height)]
		cCoords = set()
		ends = {}
		#free = {}
		# Next n lines are circle grid
		for i in range(height):
			row = f.readline().strip()
			for j in range(len(row)):
				cGrid[i][j] = row[j]
				if row[j] not in (".", "┘", "┐", "┌", "└", "─", "│", "↑", "↓", "→", "←"):
					cCoords.add((i,j))
					if cGrid[i][j] in ends:
						ends[cGrid[i][j]] += 1
					else:
						ends[cGrid[i][j]] = 1
		# Next n lines are region grid
		for i in range(height):
			row = f.readline().strip()
			for j in range(len(row)):
				rGrid[i][j] = row[j]
		# Finally, we have to uncount any circles that are in their own region from the ends calculation
		for i in range(height):
			for j in range(width):
				if cGrid[i][j] == rGrid[i][j]:
					ends[cGrid[i][j]] = ends[cGrid[i][j]] - 1
	return Hikkosu(cGrid, rGrid, cCoords, ends, height, width, None, None)

def generate_hikkosu():
	# Prepare regions to generate circles for
	global SOLUTION, MULTIPLE_SOLUTIONS
	(rGrid, regionSet, height, width) = rgrid_from_text()
	i = 0
	while True:
		print("Loop", i, SOLUTION, MULTIPLE_SOLUTIONS)
		MULTIPLE_SOLUTIONS = False
		SOLUTION = False
		(cGrid, cCoords, ends) = cgrid_bogo(rGrid, regionSet, 1+(width*height)//5)
		hik = Hikkosu(cGrid, rGrid, cCoords, ends, height, width, None, None)
		hik.disp()
		solve_hikkosu(hik)
		if SOLUTION and not MULTIPLE_SOLUTIONS:
			break
		i = i + 1
	# Clean up cGrid to remove pre-solved tiles
	for i in range(height):
		for j in range(width):
			if hik.cGrid[i][j] not in regionSet:
				hik.cGrid[i][j] = "."
	return (hik, SOLUTION)

def profile_solves():
	hik = init_from_text()
	hik.disp()

	cProfile.run("solve_hikkosu(init_from_text())")

def calc_statistics(unsolved, solved):
	# Dimensions
	height = unsolved.height
	width = unsolved.width
	space = unsolved.space
	# Circle number
	circleCount = len(unsolved.cCoords)
	# Line stuff
	avgLength = 0
	avgTurns = 0
	for coords in solved.cCoords:
		# First, get the line position
		nxt = False
		(x,y) = coords[1], coords[0]
		if x-1 >= 0 and (solved.cGrid[y][x-1] == "─" or solved.cGrid[y][x-1] == "┌" or solved.cGrid[y][x-1] == "└" or solved.cGrid[y][x-1] == "←"):
			nxt = (x-1,y)
		elif y-1 >= 0 and (solved.cGrid[y-1][x] == "│" or solved.cGrid[y-1][x] == "┐" or solved.cGrid[y-1][x] == "┌" or solved.cGrid[y-1][x] == "↑"):
			nxt = (x,y-1)
		elif x+1 < solved.width-1 and (solved.cGrid[y][x+1] == "─" or solved.cGrid[y][x+1] == "┘" or solved.cGrid[y][x+1] == "┐" or solved.cGrid[y][x+1] == "→"):
			nxt = (x+1,y)
		elif y+1 < solved.height-1 and (solved.cGrid[y+1][x] == "│" or solved.cGrid[y+1][x] == "┘" or solved.cGrid[y+1][x] == "└" or solved.cGrid[y+1][x] == "↓"):
			nxt = (x,y+1)
		# If there's no line and the board is full, solution is invalid unless circle is already in its home region
		if not nxt:
			# If there's no line, we can skip trying to follow it!
			continue
		# If there is a line, we must follow it to see where it leads
		(prvX, prvY) = x,y
		(curX, curY) = nxt[0], nxt[1]
		(nxtX, nxtY) = 0,0
		while solved.cGrid[curY][curX] not in (".", "↑", "↓", "→", "←"):
			# Update stats
			avgLength = avgLength + 1
			if solved.cGrid[curY][curX] in ("┌", "└", "┐", "┘"):
				avgTurns = avgTurns + 1
			# Next, figure out which direction we're moving
			# If we're not moving in either direction, the line lead into a line without terminating in an arrow, which is invalid
			# This is some of the most disgusting logic I've ever written
			# Python can emulate switch statements with dictionaries, but if I wanted to do that kind of thing, I'd be writing this in Lua
			(nxtX, nxtY) = SWITCHER[solved.cGrid[curY][curX]](curX,curY,prvX,prvY)
			# nxt -> nxtPos; prevPos -> nxt
			(prvX, prvY) = curX, curY
			(curX, curY) = nxtX, nxtY
	avgLength = avgLength/circleCount
	avgTurns = avgTurns/circleCount
	return (height, width, space, circleCount, avgLength, avgTurns)

def main():
	hik = init_from_text()
	hik.disp()
	solve_hikkosu(hik)
	if not SOLUTION:
		print("No solution...")
		return (None, None)
	elif MULTIPLE_SOLUTIONS:
		print("Multiple solutions ;_;")
		SOLUTION.disp()
		return (None, None)
	else:
		print("Only one solution found!")
		SOLUTION.disp()
		return (hik, SOLUTION)

def cgrid_test():
	rGrid = [["A","A","B","B","C"],["A","A","B","B","C"],["D","D","E","E","C"],["D","D","E","E","C"],["F","F","F","F","C"]]
	cGrid = [[".",".",".",".","."],["A",".",".",".","."],[".",".","B",".","A"],[".",".","B",".","."],[".",".","D",".","C"]]
	cCoords = {(1,0),(2,2),(2,4),(3,2),(4,4),(4,2)}
	ends = {"A": 1, "B": 2, "D": 1, "C": 0}
	regionSet = {"A", "B", "C", "D", "E"}
	smart_cgrid(rGrid, cGrid, cCoords, ends, regionSet, 5, 5)	

#profile_solves()
#main()
#generate_hikkosu()
#solution_test()
if sys.argv[2] == "generate":
	(unsolved, solved) = generate_hikkosu()
	unsolved.disp()
	solved.disp()
	print(calc_statistics(unsolved, solved))

elif sys.argv[2] == "solve":
	(unsolved, solved) = main()
	if unsolved:
		print(calc_statistics(unsolved, solved))
else:
	hik = init_from_text()
	hik.ends = {"A": 0, "C": 0, "D": 0, "E": 0, "F": 0, "G": 1}
	hik.disp()
	solve_hikkosu(hik)
	print(SOLUTION, MULTIPLE_SOLUTIONS)